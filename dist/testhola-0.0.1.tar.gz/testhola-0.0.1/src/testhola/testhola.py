def hola(hola):
    print(hola)